#include <pthread.h>

int main()
{
  pthread_create(NULL,NULL,NULL,NULL);
	return 0;
}
