/*
 * myth_log_proto.h
 *
 *  Created on: 2010/12/08
 *      Author: jnakashima
 */

#ifndef MYTH_LOG_PROTO_H_
#define MYTH_LOG_PROTO_H_

//nothing to define

#endif /* MYTH_LOG_PROTO_H_ */
