/*
 * myth_tls_proto.h
 *
 *  Created on: 2011/05/17
 *      Author: jnakashima
 */

#ifndef MYTH_TLS_PROTO_H_
#define MYTH_TLS_PROTO_H_

//nothing to define

#endif /* MYTH_TLS_PROTO_H_ */
