
#ifndef MYTH_IF_PTHREAD_H_
#define MYTH_IF_PTHREAD_H_

#include <pthread.h>

#endif /* MYTH_PTHREAD_IF_H_ */
