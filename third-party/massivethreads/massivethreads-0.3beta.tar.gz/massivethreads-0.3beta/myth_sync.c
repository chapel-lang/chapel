
#include "myth_misc.h"
#include "myth_desc.h"
#include "myth_worker.h"
#include "myth_sync.h"
#include "myth_sync_proto.h"

#include "myth_worker_func.h"
#include "myth_sync_func.h"

//All the functions are written in myth_sync_func.h to minimize overheads by inlining
