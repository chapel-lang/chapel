

namespace nanos {
  namespace OpenMP {
    int * ssCompatibility = (int *)1;
  }
}

