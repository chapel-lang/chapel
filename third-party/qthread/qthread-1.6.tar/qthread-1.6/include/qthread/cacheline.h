#ifndef QTHREAD_CACHELINE_H
#define QTHREAD_CACHELINE_H

#ifdef __cplusplus
extern "C" {
#endif
int qthread_cacheline(void);
#ifdef __cplusplus
}
#endif

#endif // ifndef QTHREAD_CACHELINE_H
/* vim:set expandtab: */
