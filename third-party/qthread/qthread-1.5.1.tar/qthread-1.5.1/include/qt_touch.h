#ifndef QT_SYNCVAR_OPERATIONS_H
#define QT_SYNCVAR_OPERATIONS_H

#include "qthread/qthread.h"

void qthread_run_needed_task(syncvar_t * value);

#endif
