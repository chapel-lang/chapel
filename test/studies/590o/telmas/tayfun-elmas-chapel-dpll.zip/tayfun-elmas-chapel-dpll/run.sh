
./dpll --FILENAME=fpga/fpga10_8_sat_rcr.cnf
